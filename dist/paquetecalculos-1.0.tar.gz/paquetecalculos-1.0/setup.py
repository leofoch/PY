from setuptools import setup

setup(
    name="paquetecalculos",
    version="1.0",
    description="Paquete de potencia y suma",
    author="Leo",
    author_email="",
    url="",
    packages=["calculos","calculos.subpaquete"]
    )
