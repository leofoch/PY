def sumar(op1,op2):
    print("El resultado de la suma es: ",op1+op2)

def restar(op1,op2):
    print("El resultado de la resta es: ",op1-op2)

def multiplicar(op1,op2):
    print("El resultado del producto es: ",op1*op2)

def potenciar(op1,op2):
    print("El resultado de la potencia es: ",op1**op2)

def redondear(op1):
    print("El resultado del redondeo es: ",round(op1))
